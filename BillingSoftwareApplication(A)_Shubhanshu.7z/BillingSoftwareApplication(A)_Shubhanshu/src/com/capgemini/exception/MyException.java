package com.capgemini.exception;

public class MyException extends Exception {

	public MyException(String string) {
		System.out.println(string);

}
}
