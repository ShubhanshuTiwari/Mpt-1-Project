package com.capgemini.salesmanagment.dao;

import java.util.HashMap;

import com.capgemini.salesmanagment.bean.Sale;

public interface ISaleDAO {
public HashMap<Integer,Sale>insertSalesDetails(Sale sale);
}
