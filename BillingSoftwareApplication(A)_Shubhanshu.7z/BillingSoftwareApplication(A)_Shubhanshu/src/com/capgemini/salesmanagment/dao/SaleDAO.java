package com.capgemini.salesmanagment.dao;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.capgemini.salesmanagment.bean.Sale;

public class SaleDAO implements ISaleDAO {

	private Map<Integer,Sale> productdetails;
	
	public SaleDAO(){
		productdetails=new HashMap<>();
		LocalDate date=LocalDate.now();
		Sale sale=new Sale();
		sale.setSaleId(1500);
		sale.setProdCode(1001);
		sale.setProductName("Iphone");
		sale.setCategory("Electronics");
		sale.setSaleDate(date);
		sale.setLineTotal(10000);
		sale.setQuantity(4);
		productdetails.put(1001, sale);
		Sale sale2=new Sale();
		sale2.setSaleId(1501);
		sale2.setProdCode(1002);
		sale2.setProductName("soft toys");
		sale2.setCategory("Toys");
		sale2.setSaleDate(date);
		sale2.setLineTotal(10000);
		sale2.setQuantity(4);
		productdetails.put(1002, sale2);
		Sale sale3=new Sale();
		sale3.setSaleId(1504);
		sale3.setProdCode(1003);
		sale2.setProductName("Telescope");
		sale2.setCategory("Toys");
		sale2.setSaleDate(date);
		sale2.setLineTotal(100);
		sale2.setQuantity(4);
		productdetails.put(1003, sale3);
		Sale sale4=new Sale();
		sale4.setSaleId(1501);
		sale4.setProdCode(1004);
		sale4.setProductName("soft toys");
		sale4.setCategory("Toys");
		sale4.setSaleDate(date);
		sale4.setLineTotal(10000);
		sale4.setQuantity(4);
		productdetails.put(1004, sale4);
			
	}
	
	
	public boolean search(int id) {
		return true;
	}
	
	@Override
	public HashMap<Integer, Sale> insertSalesDetails(Sale sale) {
		// TODO Auto-generated method stub
		productdetails.put((int) Math.random(), sale);
		return (HashMap<Integer, Sale>) productdetails;
	}

	
	public List<Sale> findAll() {
		List<Sale> sale = new ArrayList<>(productdetails.values());
		return sale;
	}
	

	
	public Sale findById(int id) {
		// TODO Auto-generated method stub
		return productdetails.get(id);
		
		
		
		
		
	}

	
	
}
