package com.capgemini.salesmanagment.ui;
import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;
import com.capgemini.exception.MyException;
import com.capgemini.salesmanagment.bean.Sale;
import com.capgemini.salesmanagment.dao.ISaleDAO;
import com.capgemini.salesmanagment.dao.SaleDAO;
import com.capgemini.salesmanagment.service.ISaleService;
import com.capgemini.salesmanagment.service.SaleService;

public class Client {
	static boolean isValid(int prodCode) throws MyException {
		if (prodCode == 1001 || prodCode == 1002 || prodCode == 1003 || prodCode == 1004)
			return true;
		else 
			throw new MyException("Id Number not match");
	}

	public static void main(String[] args) throws MyException {
		// TODO Auto-generated method stub
		ISaleService saleservice=new SaleService();
		SaleDAO saledao=new SaleDAO();
		Sale sale;
		Scanner scanner =new Scanner(System.in);
		boolean flag;
		
		while(true) {
			System.out.println("\n\n---Enter the choice---");
			System.out.println("---1-Enter the product code to display details--");
			System.out.println("--2-calculate the total cost---");
			System.out.println("--3-Display the Final Bill---");
			System.out.println("---4-Exit----");
			sale=new Sale();
			int choice =scanner.nextInt();
			switch(choice) {
			case 1:System.out.println("Enter the product in the range of 1001 to 1004");
			       	int prodcode=scanner.nextInt();
			       	if(isValid(prodcode)) {
			       Sale ob=	saledao.findById(prodcode);
			       System.out.println(ob);
			       	}
			       	else
			       	{
			       		System.out.println("Enter a valid range");
			       	}
				break;
			case 2:
			System.out.println("Enter the product code in the range of 1001 to 1004 ");
			int prodCode=scanner.nextInt();
			flag=isValid(prodCode);
			if(flag==true) {
			sale.setProdCode(prodCode);
			System.out.println("Enter the Quantatity int the range of 0 to 5");
			int quantatity=scanner.nextInt();
			if(quantatity>0||quantatity<5) {
			sale.setQuantity(quantatity);
			System.out.println("Enter the category only Electronics or Toys");
			String category=scanner.next();
			if(category=="Electronics"||category=="Toys") {
			sale.setCategory(category);
			System.out.println("Enter the product name ");
			String productName=scanner.next();
			sale.setProductName(productName);
			System.out.println("Enter the product Description");
			String description=scanner.next();
			System.out.println("Enter the product price above then 200");
			int price=scanner.nextInt();
			if(price>200) {
			System.out.println("Quantatity:"+quantatity);
			System.out.println("Line Total(Rs):"+quantatity*price);
			sale.setLineTotal(quantatity*price);
			
			}
			else 
			{
				System.out.println("Enter a valid price till now your details are");
			}
			
			}
			else {
				System.out.println("Enter a valid category till now your details are");
			}
			}
			else {
				System.out.println("Enter a quantatity in 0-5 range till now your details are");
			}
			
			}
			else {
				System.out.println("Enter a valid code till now your details are");
			}
			LocalDate date=LocalDate.now();
			sale.setSaleDate(date);
			saleservice.insertSalesDetails(sale);
			System.out.println(" details are Success fuly added");
			System.out.println("Your Item Details are ");
			List<Sale> saledetail = saledao.findAll();
			for (Sale sales : saledetail) {
				System.out.println(sales);
			}
			break;
			case 3:System.out.println("Your Item Details are ");
			List<Sale> saledetail2 = saledao.findAll();
			for (Sale sales : saledetail2) {
				System.out.println(sales);
		}
			case 4:
				System.exit(0);
				break;
			default:System.out.println("Enter a wrong choice");
					break;
			
		}	
		}
	}

}
