package com.capgemini.salesmanagment.service;

import java.util.HashMap;

import com.capgemini.salesmanagment.bean.Sale;
import com.capgemini.salesmanagment.dao.ISaleDAO;
import com.capgemini.salesmanagment.dao.SaleDAO;

public class SaleService implements ISaleService{
	ISaleDAO saledao;
	public SaleService(){
		saledao=new SaleDAO();
	}

	@Override
	public HashMap<Integer, Sale> insertSalesDetails(Sale sale) {
		// TODO Auto-generated method stub
		return saledao.insertSalesDetails(sale);
	}
	
	
	
}
