package com.capgemini.salesmanagment.service;

import java.util.HashMap;

import com.capgemini.salesmanagment.bean.Sale;

public interface ISaleService {
	public HashMap<Integer,Sale>insertSalesDetails(Sale sale);
	
}
