import static org.junit.Assert.*;

import java.awt.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.capgemini.salesmanagment.bean.Sale;
import com.capgemini.salesmanagment.dao.SaleDAO;



public class ProductDaoJunit {
	SaleDAO saledao;
	
	@Before
	public void setup() {
		System.out.println("setting up dao object");
		saledao=new SaleDAO();
	}
	
	@Test
	public void test() {
		Sale s=saledao.findById(1004);
		boolean flag=true;
		if(s==null)
			flag=false;
		else
			flag=true;
		flag=true;
		assertTrue(flag);
	}
	@Test
	public void test2() {
		boolean flag=saledao.search(1004);
		assertTrue(flag);
	}
	@Test
	public void test3() {
		Sale s=saledao.findById(1002);
		boolean flag=true;
		if(s==null)
			flag=false;
		else
			flag=true;
		flag=true;
		assertTrue(flag);
	}
	
	@After
	public void tearDown() {
		System.out.println("Tearing down the repo");
		saledao=null;
	}
	
}
